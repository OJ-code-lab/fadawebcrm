import { NextResponse } from "next/server";
import { apiFetch } from "@/lib/api";
import { cookies } from "next/headers";

export async function POST(req: Request) {
  const cookieStore = await cookies();
  const accesstoken = cookieStore.get("access_token")?.value;
  try {
    const body = await req.json();

    const { response, data } = await apiFetch(
      "business/01a0a4cb-446c-717b-ae8c-71af2a62773e/plans/01a0967d-de6b-70c7-971b-bd3580ccaad9/order/nigeria/payment",
      {
        method: "POST",
        headers: {
          "X-API-KEY": process.env.API_KEY || "",
          Authorization: `Bearer ${accesstoken}`,
        },
        body: JSON.stringify(body),
      },
    );

    if (!response.ok) {
      return NextResponse.json(
        data && typeof data === "object"
          ? data
          : {
              status: false,
              message: "Unable to initiate payment.",
              data: [],
            },
        { status: response.status },
      );
    }

    return NextResponse.json(data, {
      status: response.status,
    });
  } catch (error) {
    console.error("Unable to initiate payment error:", error);

    return NextResponse.json(
      {
        status: false,
        message:
          error instanceof Error
            ? error.message
            : "Unable to initiate payment details.",
        data: [],
      },
      { status: 500 },
    );
  }
}
