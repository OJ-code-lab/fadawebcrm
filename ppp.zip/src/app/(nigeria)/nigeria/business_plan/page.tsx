import BusinessPlan from "@/components/onboardingForm/BusinessPlan";
import { apiFetch } from "@/lib/api";
import { cookies } from "next/headers";
// import React from "react";

async function page() {
  const cookieStore = await cookies();
  const accessToken = cookieStore.get("access_token")?.value;
  try {
    const { response, data } = await apiFetch(
      "/business/01a0a4ee-d51d-7102-ad51-72de5268dea4/plans",
      {
        method: "GET",
        headers: {
          "X-API-KEY": process.env.API_KEY || "",
          Authorization: `Bearer ${accessToken}`,
        },
      },
    );

    // const data = await response.json();
    console.log("business Plan details: ", data);
    if (!response.ok) {
      console.error("Failed to fetch business details:", response.status, data);
      return <BusinessPlan businessPlanType={[]} />;
    }

    // -----------view business plan details

    const { response: orderResponse, data: orderData } = await apiFetch(
      "/business/01a0a4cb-446c-717b-ae8c-71af2a62773e/plans/01a09626-014c-70e2-8d4a-2fecb08f0848",
      {
        method: "GET",
        headers: {
          "X-API-KEY": process.env.API_KEY || "",
          Authorization: `Bearer ${accessToken}`,
        },
      },
    );

    console.log("Order details: ", orderData);
    if (!orderResponse.ok) {
      console.error(
        "failed to load order details:",
        orderResponse.status,
        orderData,
      );
    }

    const businessPlans = Array.isArray(data?.data) ? data.data : [];
    return <BusinessPlan businessPlanType={businessPlans} />;
  } catch (e) {
    console.log("business subscription error:", e);
  }

  return (
    <>
      <div>page</div>
      <BusinessPlan businessPlanType={[]} />
    </>
  );
}

export default page;
