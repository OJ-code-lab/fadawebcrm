"use client";

// import {BASE_URL, API_KEY} from "@/"

import { useState } from "react";
import { useRouter } from "next/navigation";

import { Button } from "@/components/ui/button";
// import { Input } from "@/components/ui/input";
// import { Label } from "@/components/ui/label";

import { ArrowLeftFromLine, ArrowRightFromLine } from "lucide-react";
import { Card } from "../ui/card";

type BusinessPlanItem = {
  id: string;
  name: string;
  description: string;
  total_price: string;
  formation_price: string;
  service: BusinessPlanService[];
};

type BusinessPlanService = {
  id: string;
  title: string;
};

type BusinessSummery = {
  id: string;
  // company name & plan type
  name: string;
  entity_type: string;
  state: string;
  citizenship: string;
  // price
  formatted: string;
  state_fee: string;
};

type BusinessPlanProps = {
  // entityTypes?: EntityType[];
  // countryId?: string;
  businessPlanType?: BusinessPlanItem[];
  businessSummary?: BusinessSummery[];
};

// -------------------------------------
export interface FormData {
  business_country_id: string;
  state: string;
  company_name: string;
  companySecondName: string;
  registration_type: string;
  industry_id: string;
}

const initialFormData: FormData = {
  business_country_id: "",
  state: "",
  company_name: "",
  companySecondName: "",
  registration_type: "",
  industry_id: "",
};

interface ProgressBarProps {
  currentStep: number;
  totalSteps: number;
}

function StepProgressBar({ currentStep, totalSteps }: ProgressBarProps) {
  return (
    <div className="mb-6 flex w-full items-center justify-between gap-1 overflow-x-auto pb-1 sm:gap-2">
      {Array.from({ length: totalSteps }).map((_, index) => {
        const stepNumber = index + 1;
        // const isCompleted = stepNumber < currentStep;
        const isCurrent = stepNumber === currentStep;

        return (
          <div key={stepNumber} className="flex items-center flex-1">
            {/* Connecting Line */}
            {stepNumber < totalSteps && (
              <div
                className={`mx-1 h-0.5 min-w-1 flex-1 rounded-4xl transition-colors sm:mx-2 sm:h-1
                  // 
                   ${
                     stepNumber < currentStep
                       ? "bg-green-600"
                       : isCurrent
                         ? "bg-blue-600"
                         : "bg-gray-50"
                   }`}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}

const isStepValid = (step: number, data: FormData): boolean => {
  switch (step) {
    case 1:
      return data.state.trim() !== "";
    case 2:
      return data.company_name.trim() !== "";
    case 3:
      return data.registration_type.trim() !== "";
    case 4:
      return data.industry_id.trim() !== "";
    default:
      return false;
  }
};

function BusinessPlan({
  // entityTypes = [],
  // countryId = "",
  businessPlanType = [],
}: BusinessPlanProps) {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const updateField = (key: keyof FormData, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  };

  const handleNext = () => {
    if (isStepValid(currentStep, formData) && currentStep < 2) {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!isStepValid(currentStep, formData)) {
      return;
    }

    setIsSubmitting(true);

    // passing countryid props

    const businessDatas = {
      // business_country_id: countryId,
      // company_name: formData.company_name,
      // companySecondName: formData.companySecondName,
      // state: formData.state,
      // registration_type: formData.registration_type,
      // industry_id: formData.industry_id,
    };

    try {
      console.log("businessDatas being sent:", businessDatas);
      console.log("current formData:", formData);
      const response = await fetch("/api/businessPlan", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(businessDatas),
      });

      const data = await response.json();

      console.log("Business plan data:", data);

      if (!response.ok) {
        console.error("BusinessPlan creation failed:", data);
        return;
      }

      router.push(`/nigeria/business_plan/${data.id}`);
    } catch (error) {
      console.error("Business creation error:", error);
    } finally {
      setIsSubmitting(false);
    }
  };
  return (
    <>
      <div className="grid place-items-center pt-8`">
        <StepProgressBar currentStep={currentStep} totalSteps={2} />

        <div className="my-4 text-center">
          <h3 className="font-bold text-4xl leading-11 text-black">
            {"Let's make it official."}
          </h3>
          <p className="font-medium text-lg leading-7 text-light-black">
            Get your EIN, US Bank Account, US Business Address, Registered Agent
            Services, and more.
          </p>
        </div>
        <form onSubmit={handleSubmit} className="min-w-0 space-y-4">
          {/* STEP 1 */}
          {currentStep === 1 && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 w-full max-w-6xl p-4">
              {businessPlanType.map((plan) => {
                const isPlus = plan.name.toLowerCase().includes("growth");

                return (
                  <Card
                    key={plan.id}
                    className={`flex flex-col justify-between p-6 text-sm font-normal shadow border-0 ${
                      isPlus
                        ? "bg-blue-card text-white border-transparent"
                        : "bg-primary text-light-black border-0"
                    }`}
                  >
                    <div className="space-y-4">
                      <div>
                        <h4
                          className={`text-xl font-semibold capitalize ${
                            isPlus ? "text-white" : "text-black"
                          }`}
                        >
                          {plan.name}
                        </h4>
                        <p
                          className={` ${isPlus ? "text-gray-200" : "text-gray-600"}`}
                        >
                          {plan.description}
                        </p>
                      </div>

                      <div className="flex gap-2 relative">
                        <p
                          className={`font-bold text-3xl ${
                            isPlus ? "text-white" : "text-black"
                          }`}
                        >
                          {plan.total_price}
                        </p>
                        <span className="text-xs opacity-80 items-end absolute bottom-0 right-0 ">
                          / Month
                        </span>
                      </div>

                      <Button
                        className={`w-full rounded-4xl capitalize ${
                          isPlus
                            ? "bg-primary text-black hover:bg-gray-100"
                            : "bg-primary text-black border border-gray-200 hover:bg-gray-50"
                        }`}
                      >
                        Select {plan.name}
                      </Button>

                      <div className={`pt-2 border-t border-gray-200/20 `}>
                        {/* <h5 className="font-semibold">
                          Formation Price: {plan.formation_price}
                        </h5> */}
                        {plan.service.length > 0 ? (
                          <ul className="mt-2 space-y-1 list-none list-inside ">
                            {plan.service.map((item) => (
                              <li key={item.id}>
                                <div
                                  className={`font-medium text-[15px] ${isPlus ? "" : "text-black"}`}
                                >
                                  <span className="pr-2">✓</span>
                                  {item.title || "Included Service"}
                                </div>
                                <p
                                  className={`${isPlus ? "text-gray-50/60" : ""}`}
                                >
                                  Articles of organization + operating agreement
                                  included
                                </p>
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="opacity-80 mt-1">
                            <span className="pr-2">✓</span>
                            Basic formation documents included
                          </p>
                        )}
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}

          {/* STEP 2 */}
          {currentStep === 2 && (
            <div>
              <div>
                <h4 className="font-semibold text-2xl text-center ">
                  Review your details
                </h4>

                <p className="font-light text-base text-light-black">
                  {"You'll be able to change your company name after payment."}
                </p>
              </div>
              <div className="flex flex-col gap-4 lg:flex-row">
                <div className=" bg-blue-card/20 font-normal text-lg text-black">
                  <h2 className="font-bold text-2xl leading-9">Subscription</h2>
                  <div>
                    <div className="flex justify-between gap-4">
                      <p>Package</p>
                      <p>Tax Compliance</p>
                    </div>
                    <div className="flex justify-between gap-4">
                      <p>Price</p>
                      <p>$1,990.00</p>
                    </div>
                    <div className="flex justify-between gap-4">
                      <p>Billing</p>
                      <p>Annual</p>
                    </div>

                    <button className="p-4">Edit</button>
                  </div>
                </div>
                <div className="font-normal text-lg text-black">
                  <h2 className="font-bold text-2xl leading-9">Subscription</h2>
                  <div>
                    <div className="flex justify-between gap-4">
                      <p>Package</p>
                      <p>Tax Compliance</p>
                    </div>
                    <div className="flex justify-between gap-4">
                      <p>Price</p>
                      <p>$1,990.00</p>
                    </div>
                    <div className="flex justify-between gap-4">
                      <p>Billing</p>
                      <p>Annual</p>
                    </div>

                    <button className="p-4">Edit</button>
                  </div>
                </div>
                <div className="bg-blue-card/20 font-normal text-lg text-black">
                  <h2 className="font-bold text-2xl leading-9">Subscription</h2>
                  <div>
                    <div className="flex justify-between gap-4">
                      <p>Package</p>
                      <p>Tax Compliance</p>
                    </div>
                    <div className="flex justify-between gap-4">
                      <p>Price</p>
                      <p>$1,990.00</p>
                    </div>
                    <div className="flex justify-between gap-4">
                      <p>Billing</p>
                      <p>Annual</p>
                    </div>

                    <button className="p-4">Edit</button>
                  </div>
                </div>
              </div>
              <div></div>
            </div>
          )}

          {/* Navigation Controls */}
          <div className="flex justify-between pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleBack}
              disabled={currentStep === 1}
              className={`rounded-4xl text-black
                 ${
                   !isStepValid(currentStep, formData)
                     ? " bg-amber-500/40 hover:bg-amber-500/70"
                     : "bg-amber-500/20 hover:bg-amber-500/70"
                 }
                `}
            >
              <span>
                <ArrowLeftFromLine />
              </span>
              Back
            </Button>

            {currentStep < 4 ? (
              <Button
                type="button"
                onClick={handleNext}
                disabled={!isStepValid(currentStep, formData)}
                className={`rounded-4xl text-white border-0
                 ${
                   !isStepValid(currentStep, formData)
                     ? " bg-gray-400"
                     : "bg-blue-card hover:bg-blue-900"
                 }
                `}
              >
                Next
                <span>
                  <ArrowRightFromLine />
                </span>
              </Button>
            ) : (
              <Button
                type="submit"
                disabled={!isStepValid(currentStep, formData) || isSubmitting}
                className={`rounded-4xl text-white
                 ${
                   !isStepValid(currentStep, formData)
                     ? " bg-green-500"
                     : "bg-green-500 hover:bg-green-600"
                 }
                `}
              >
                Submit
              </Button>
            )}
          </div>
        </form>
      </div>
    </>
  );
}

export default BusinessPlan;
