import { NextRequest, NextResponse } from "next/server";
import { apiFetch } from "@/lib/api";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const { response, data } = await apiFetch("/business/createNg", {
      method: "POST",
      body: JSON.stringify(body),
    });

    return NextResponse.json(data, {
      status: response.status,
    });
  } catch (error) {
    console.error("Create business error:", error);

    return NextResponse.json(
      {
        status: false,
        message: "Something went wrong",
      },
      { status: 500 },
    );
  }
}
