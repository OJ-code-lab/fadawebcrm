import { NextResponse } from "next/server";
import { apiFetch } from "@/lib/api";

export async function GET() {
  try {
    const { response, data } = await apiFetch("/registration_type", {
      method: "GET",
      headers: {
        "X-API-KEY": process.env.API_KEY || "",
      },
    });

    if (!response.ok) {
      return NextResponse.json(
        {
          status: false,
          message: "Unable to fetch registration type.",
          data: [],
        },
        { status: response.status },
      );
    }

    return NextResponse.json(data, {
      status: response.status,
    });
  } catch (error) {
    console.error("Countries fetch failed:", error);

    return NextResponse.json(
      {
        status: false,
        message: "Registration types are temporarily unavailable.",
        data: [],
      },
      { status: 500 },
    );
  }
}
