import OnBoardingForm from "@/components/onboardingForm/OnBoardingForm";

import { apiFetch } from "@/lib/api";
// import NigeriaForm from "@/components/NigeriaForm";

async function onboardingFormPage() {
  const { response, data } = await apiFetch("/business/type", {
    method: "GET",
    headers: {
      "X-API-KEY": process.env.API_KEY || "",
    },
  });

  if (!response.ok) {
    throw new Error("Failed to fetch entity types");
  }

  return (
    <div className="grid place-items-center h-screen">
      <OnBoardingForm entityTypes={data?.data ?? []} />
    </div>
  );
}
export default onboardingFormPage;
